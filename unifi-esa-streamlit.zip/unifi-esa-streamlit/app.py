"""UniFi Enterprise Sales Approval: Streamlit app.

Run locally:  streamlit run app.py
"""

from __future__ import annotations

import re
from datetime import date
from pathlib import Path

import streamlit as st

from esa import mailer
from esa import reference as refdata
from esa.excel import export_workbook, offering_text, products_of, request_workbook
from esa.store import NotAllowed, Store, engine_for
from esa.validation import ADDRESS_FIELDS, COMPANY_FIELDS, CONTACT_FIELDS, EMAIL_RX, PARTY_FIELDS, step_errors

ROOT = Path(__file__).parent
TEMPLATE = ROOT / "templates" / "ESA_Template.xlsx"
LOGO = ROOT / "assets" / "cometogether.png"
TITLE = "UniFi Enterprise Sales Approval"
STEPS = [("Intended Product Use", "Product use"), ("Seller Information", "Seller"),
         ("End-User Information", "End user"), ("Deal Registration", "Deal"), ("Review", "Review")]
PROVIDER_LABELS = {"microsoft": "Microsoft", "google": "Google"}

st.set_page_config(page_title=TITLE, page_icon=str(LOGO), layout="centered")


# ---------------------------------------------------------------- settings
def secret(path: str, default=None):
    """Read a value from .streamlit/secrets.toml (or Streamlit Cloud secrets); default if missing."""
    try:
        node = st.secrets
        for part in path.split("."):
            node = node[part]
        return node
    except Exception:
        return default


_AUTH = secret("auth", {}) or {}
# Named providers ([auth.microsoft], [auth.google]) or one provider written directly under [auth] (None).
AUTH_PROVIDERS = [k for k, v in _AUTH.items() if hasattr(v, "keys")] or ([None] if "client_id" in _AUTH else [])
DEMO_LOGIN = bool(secret("app.demo_login", not AUTH_PROVIDERS))
ADMIN_EMAILS = tuple(e.lower() for e in secret("app.admin_emails", []))
ALLOWED_DOMAINS = [d.lower().lstrip("@") for d in secret("app.allowed_domains", [])]
NOTIFY_TO = list(secret("app.notify_to", []))
APP_URL = secret("app.app_url", "")
SMTP = mailer.SmtpConfig.from_dict(secret("smtp", {}))


@st.cache_resource
def get_store(url: str, admins: tuple[str, ...]) -> Store:
    return Store(engine_for(url), list(admins))


store = get_store(secret("app.database_url", ""), ADMIN_EMAILS)
SKUS = refdata.load_skus(str(TEMPLATE))
SKU_NO = dict(SKUS)
ss = st.session_state


# ---------------------------------------------------------------- session state
def init_state() -> None:
    defaults = {"step": -1, "view": "form", "n_products": 1, "show_err": set(), "done": None,
                "fresh": set(), "flash": None}
    for k, v in defaults.items():
        ss.setdefault(k, v)
    form_defaults = {"f_use": None, "f_s_employees": None, "f_s_offering": None, "f_s_offering_other": "",
                     "f_date": None, "f_scope": "", "f_order": ""}
    for p in ("s", "e"):
        for key, _, kind in PARTY_FIELDS:
            form_defaults[f"f_{p}_{key}"] = None if kind == "country" else ""
    for i in range(ss.n_products):
        form_defaults.setdefault(f"f_sku_{i}", None)
        form_defaults.setdefault(f"f_qty_{i}", 1)
    for k, v in form_defaults.items():
        ss.setdefault(k, v)
    # Keep answers from steps that are not on screen (Streamlit forgets hidden widgets otherwise).
    for k in list(ss.keys()):
        if isinstance(k, str) and k.startswith("f_"):
            ss[k] = ss[k]


def clear_form() -> None:
    for k in [k for k in ss.keys() if isinstance(k, str) and k.startswith("f_")]:
        del ss[k]
    ss.n_products, ss.show_err = 1, set()


def collect() -> dict:
    g = ss.get

    def party(p: str) -> dict:
        return {key: (g(f"f_{p}_{key}") or "").strip() for key, _, _ in PARTY_FIELDS}

    seller = party("s") | {"employees": g("f_s_employees") or "", "offering": g("f_s_offering") or "",
                           "offering_other": (g("f_s_offering_other") or "").strip()}
    products = [{"sku": g(f"f_sku_{i}"), "qty": int(g(f"f_qty_{i}") or 0)} for i in range(ss.n_products)]
    return {"use": g("f_use") or "", "seller": seller, "end": party("e"), "products": products,
            "sales_date": g("f_date"), "scope": (g("f_scope") or "").strip(), "order_no": (g("f_order") or "").strip()}


# ---------------------------------------------------------------- auth
def logged_in() -> bool:
    return bool(st.user.get("is_logged_in", False))


def current_user() -> dict | None:
    if AUTH_PROVIDERS and logged_in():
        email = st.user.get("email") or st.user.get("preferred_username") or ""
        return {"email": str(email).lower(), "name": st.user.get("name") or ""}
    return ss.get("demo_user") if DEMO_LOGIN else None


def domain_ok(email: str) -> bool:
    return not ALLOWED_DOMAINS or any(email.endswith("@" + d) for d in ALLOWED_DOMAINS)


def sign_out() -> None:
    clear_form()
    for k in ("demo_user", "done", "fresh"):
        ss.pop(k, None)
    ss.step, ss.view = -1, "form"
    if AUTH_PROVIDERS and logged_in():
        st.logout()
    st.rerun()


# ---------------------------------------------------------------- small UI helpers
MD_SPECIAL = re.compile(r"([\\`*_{}\[\]()#+\-.!|>~$<])")


def md(value) -> str:
    """Show user text literally in markdown."""
    return MD_SPECIAL.sub(r"\\\1", str(value or "—")).replace("\n", "  \n")


def error(msg: str | None) -> None:
    if msg:
        st.caption(f":red[{msg}]")


def kv(rows: list[tuple[str, object]]) -> None:
    for label, value in rows:
        a, b = st.columns([2, 3])
        a.caption(label)
        b.markdown(md(value))


def party_rows(p: dict, seller: bool) -> list[tuple[str, str]]:
    rows = [("Company Name", p.get("company")), ("Company Website", p.get("website"))]
    if seller:
        rows += [("Total Number of Employees", p.get("employees")), ("Company Offerings", offering_text(p))]
    rows += [("Country", p.get("country")), ("Street Address", p.get("street")),
             ("State / Province", p.get("state")), ("City", p.get("city")), ("Postal Code", p.get("postal")),
             ("Contact Name", p.get("contact")), ("Contact Phone Number", p.get("phone")),
             ("Contact Email Address", p.get("email"))]
    return rows


def fmt_date(v) -> str:
    try:
        return (v if isinstance(v, date) else date.fromisoformat(str(v))).strftime("%d/%m/%Y")
    except ValueError:
        return str(v or "")


def status_badge(status: str) -> None:
    st.badge(status, color={"Approved": "green", "Rejected": "red"}.get(status, "orange"))


def excel_name(ref: str) -> str:
    return f"{ref} {TITLE}.xlsx"


# ---------------------------------------------------------------- navigation callbacks
def go(step: int) -> None:
    ss.step, ss.view = step, "form"


def set_view(view: str) -> None:
    ss.view = view
    if view == "form" and ss.step == 5:
        ss.step, ss.done = -1, None


def next_step(i: int) -> None:
    errs = step_errors(i, collect(), date.today())
    if errs:
        ss.show_err.add(i)
        ss.flash = "One field needs your attention." if len(errs) == 1 else f"{len(errs)} fields need your attention."
    else:
        ss.show_err.discard(i)
        ss.step = i + 1


def add_product() -> None:
    n = ss.n_products
    ss[f"f_sku_{n}"], ss[f"f_qty_{n}"] = None, 1
    ss.n_products = n + 1


def remove_product(i: int) -> None:
    n = ss.n_products
    for j in range(i, n - 1):
        ss[f"f_sku_{j}"], ss[f"f_qty_{j}"] = ss.get(f"f_sku_{j + 1}"), ss.get(f"f_qty_{j + 1}", 1)
    ss.pop(f"f_sku_{n - 1}", None)
    ss.pop(f"f_qty_{n - 1}", None)
    ss.n_products = n - 1


def submit(user: dict) -> None:
    req = collect()
    bad = [i for i in range(4) if step_errors(i, req, date.today())]
    if bad:
        ss.show_err.update(bad)
        ss.step = bad[0]
        ss.flash = f"Some details are missing in {STEPS[bad[0]][0]}."
        return
    row = store.add(user["email"], user["name"], req)
    mailed, mail_error = None, ""
    if NOTIFY_TO and SMTP.enabled:
        try:
            xlsx = request_workbook(TEMPLATE, row["data"], row["ref"], user["email"])
            subject, text_body, html_body = mailer.new_request_message(row, APP_URL)
            mailer.send(SMTP, NOTIFY_TO, subject, text_body, html_body, [(excel_name(row["ref"]), xlsx)])
            store.mark_notified(row["ref"])
            mailed = True
        except Exception as e:  # keep the request even if email fails
            mailed, mail_error = False, str(e)
    ss.done = {"ref": row["ref"], "mailed": mailed, "mail_error": mail_error}
    clear_form()
    ss.step = 5


# ---------------------------------------------------------------- form widgets
def text_field(key: str, label: str, errs: dict, ek: str, placeholder: str = "", help_: str | None = None) -> None:
    st.text_input(label, key=key, placeholder=placeholder, help=help_)
    error(errs.get(ek))


def party_fields(prefix: str, errs: dict, seller: bool) -> None:
    with st.container(border=True):
        st.markdown("**Company**")
        text_field(f"f_{prefix}_company", "Company Name", errs, "company")
        text_field(f"f_{prefix}_website", "Company Website", errs, "website", "www.company.com")
        if seller:
            st.radio("Total Number of Employees", refdata.EMPLOYEES, key="f_s_employees", horizontal=True)
            error(errs.get("employees"))
            st.radio("Company Offerings", refdata.OFFERINGS, key="f_s_offering",
                     format_func=lambda o: "Other (please describe)" if o == "Other" else o)
            error(errs.get("offering"))
            if ss.get("f_s_offering") == "Other":
                text_field("f_s_offering_other", "Describe your offering", errs, "offering_other",
                           "e.g. IT reseller, security installer")
    with st.container(border=True):
        st.markdown("**Address**")
        st.selectbox("Country", refdata.countries(), key=f"f_{prefix}_country", placeholder="Choose…")
        error(errs.get("country"))
        text_field(f"f_{prefix}_street", "Street Address", errs, "street")
        a, b = st.columns(2)
        with a:
            text_field(f"f_{prefix}_state", "State / Province", errs, "state")
        with b:
            text_field(f"f_{prefix}_city", "City", errs, "city")
        text_field(f"f_{prefix}_postal", "Postal Code", errs, "postal")
    with st.container(border=True):
        st.markdown("**Contact**")
        text_field(f"f_{prefix}_contact", "Contact Name", errs, "contact")
        text_field(f"f_{prefix}_phone", "Contact Phone Number", errs, "phone", "+48 22 123 45 67",
                   "Include the country code, for example +48.")
        text_field(f"f_{prefix}_email", "Contact Email Address", errs, "email", "name@company.com")


def deal_fields(errs: dict) -> None:
    for i in range(ss.n_products):
        with st.container(border=True):
            head, rm = st.columns([4, 1])
            head.markdown(f"**Product {i + 1}**")
            if ss.n_products > 1:
                rm.button("Remove", key=f"rm_{i}", on_click=remove_product, args=(i,), type="tertiary")
            a, b = st.columns([3, 1])
            with a:
                st.selectbox("Enterprise Product", [s for s, _ in SKUS], key=f"f_sku_{i}",
                             placeholder="Choose a product…", format_func=lambda s: f"{s}  ·  {SKU_NO.get(s, '')}")
                error(errs.get(f"sku{i}"))
            with b:
                st.number_input("Quantity", min_value=1, step=1, key=f"f_qty_{i}")
                error(errs.get(f"qty{i}"))
    st.button("＋ Add another product", on_click=add_product, type="tertiary")
    with st.container(border=True):
        st.markdown("**Project**")
        st.date_input("Estimated Sales Date", key="f_date", min_value=date.today(), format="DD/MM/YYYY")
        error(errs.get("sales_date"))
        st.text_area("Description of Project Scope", key="f_scope", max_chars=2000, height=150,
                     placeholder="Sites, number of devices, network design, timeline and anything else that helps the approval.")
        error(errs.get("scope"))


# ---------------------------------------------------------------- pages
def page_sign_in() -> None:
    st.image(str(LOGO), width=180)
    st.title(TITLE)
    st.write("Sign in to request approval to sell UniFi Enterprise products.")
    for p in AUTH_PROVIDERS:
        label = f"Sign in with {PROVIDER_LABELS.get(p, str(p).title())}" if p else "Sign in"
        if st.button(label, type="primary", use_container_width=True, key=f"login_{p or 'default'}"):
            st.login(p) if p else st.login()
    if DEMO_LOGIN:
        st.info("Demo sign-in: anyone can enter any email here. Set up Microsoft or Google sign-in "
                "in secrets before sharing the app (see README).")
        email = st.text_input("Email", key="demo_email", placeholder="name@company.com")
        if st.button("Continue", type="secondary" if AUTH_PROVIDERS else "primary", key="demo_continue"):
            e = (email or "").strip().lower()
            if not EMAIL_RX.match(e):
                st.error("Enter an email address such as name@company.com.")
            elif not domain_ok(e):
                st.error(f"Use your work email ({', '.join('@' + d for d in ALLOWED_DOMAINS)}).")
            else:
                ss.demo_user = {"email": e, "name": ""}
                st.rerun()


def page_welcome(user: dict) -> None:
    st.image(str(LOGO), width=180)
    st.title(TITLE)
    st.write("Request approval to sell UniFi Enterprise products for your project.")
    st.button("Start request", type="primary", on_click=go, args=(0,))
    if not store.is_admin(user["email"]):
        news = [r for r in store.mine(user["email"]) if r["status"] != r["seen_status"]]
        if news:
            msg = (f"Request {news[0]['ref']} was {news[0]['status'].lower()}." if len(news) == 1
                   else f"{len(news)} of your requests have a new status.")
            st.info(msg)
            st.button("View my requests", on_click=set_view, args=("mine",))


def page_step(i: int) -> None:
    title, _ = STEPS[i]
    st.progress((i + 1) / 5, text=f"Step {i + 1} of 4 · {title}")
    st.header(title)
    errs = step_errors(i, collect(), date.today()) if i in ss.show_err else {}
    if i == 0:
        st.radio("How will the UniFi Enterprise products be used?", [u for u, _ in refdata.USES], key="f_use",
                 captions=[c for _, c in refdata.USES])
        error(errs.get("use"))
    elif i == 1:
        st.write("Tell us about the company selling the products.")
        party_fields("s", errs, seller=True)
    elif i == 2:
        st.write("Tell us about the customer who will use the products.")
        party_fields("e", errs, seller=False)
    else:
        st.write("List the Enterprise products and quantities, then describe the project.")
        deal_fields(errs)
    if errs and ss.flash:
        st.error(ss.flash)
    a, _, b = st.columns([1, 2, 1])
    a.button("Back", on_click=go, args=(i - 1,), use_container_width=True)
    b.button("Review request" if i == 3 else "Continue", type="primary", on_click=next_step, args=(i,),
             use_container_width=True)


def page_review(user: dict) -> None:
    st.progress(1.0, text="Review")
    st.header("Review your request")
    st.write("Check the details. Use Edit to change a section.")
    req = collect()
    sections = [
        ("Intended Product Use", 0, [("Intended Product Use", req["use"])]),
        ("Seller Information", 1, party_rows(req["seller"], True)),
        ("End-User Information", 2, party_rows(req["end"], False)),
        ("Deal Registration", 3, [(f"Product {n + 1}", f"{p['sku']} ({SKU_NO.get(p['sku'], '')}) × {p['qty']}")
                                  for n, p in enumerate(products_of(req))]
         + [("Estimated Sales Date", fmt_date(req["sales_date"])), ("Description of Project Scope", req["scope"])]),
    ]
    for title, step, rows in sections:
        with st.container(border=True):
            h, e = st.columns([4, 1])
            h.markdown(f"**{title}**")
            e.button("Edit", key=f"edit_{step}", on_click=go, args=(step,), type="tertiary")
            kv(rows)
    with st.container(border=True):
        st.text_input("Order Number (optional)", key="f_order", max_chars=60, placeholder="e.g. PO-2026-0412")
    st.caption("Submitting saves your request and emails it to the EET team as an Excel file. "
               "You'll see the decision under My requests and get an email when it's approved or rejected.")
    a, _, b = st.columns([1, 2, 1])
    a.button("Back", on_click=go, args=(3,), use_container_width=True)
    b.button("Submit request", type="primary", on_click=submit, args=(user,), use_container_width=True)


def page_done(user: dict) -> None:
    d = ss.done or {}
    st.success(f"Request {d.get('ref')} submitted.")
    st.write("EET has received your request. You'll see status updates under My requests. "
             f"Keep the reference **{md(d.get('ref'))}** for any questions.")
    if d.get("mailed") is False:
        st.warning("Your request is saved, but the email to the EET team couldn't be sent. "
                   "The team still sees it in the request list.")
    row = store.get_for(user["email"], d["ref"])
    a, b, c = st.columns(3)
    a.download_button("Download Excel", request_workbook(TEMPLATE, row["data"], row["ref"], user["email"]),
                      file_name=excel_name(row["ref"]), use_container_width=True)
    b.button("My requests", on_click=set_view, args=("mine",), use_container_width=True)
    c.button("New request", on_click=lambda: (set_view("form"), go(-1)), use_container_width=True)


def page_mine(user: dict) -> None:
    st.header("My requests")
    st.write("Requests you submitted and their approval status.")
    rows = store.mine(user["email"])
    if not rows:
        st.info("No requests yet. Requests you submit will appear here with their status.")
        return
    unseen = [r["ref"] for r in rows if r["status"] != r["seen_status"]]
    ss.fresh.update(unseen)
    for r in rows:
        d = r["data"]
        units = sum(int(p["qty"]) for p in products_of(d))
        label = f"{d['seller'].get('company')} → {d['end'].get('company')} · {r['ref']} · {r['status']}"
        if r["ref"] in ss.fresh:
            label += " · Updated"
        with st.expander(label):
            status_badge(r["status"])
            kv([("Submitted", r["created_at"][:16].replace("T", " ")), ("Intended use", d.get("use"))]
               + [(f"Product {n + 1}", f"{p['sku']} × {p['qty']}") for n, p in enumerate(products_of(d))]
               + [("Total units", units), ("Estimated sales date", fmt_date(d.get("sales_date"))),
                  ("Order number", d.get("order_no") or "—"),
                  ("Status updated", (r["status_at"] or "—")[:16].replace("T", " "))])
            st.download_button("Download Excel", request_workbook(TEMPLATE, d, r["ref"], user["email"]),
                               file_name=excel_name(r["ref"]), key=f"dl_{r['ref']}")
    store.mark_seen(user["email"], unseen)


def page_admin(user: dict) -> None:
    st.header("All requests")
    st.write("Every request submitted through this app. Only admins see this list.")
    rows = store.all(user["email"])
    m = st.columns(4)
    m[0].metric("Requests", len(rows))
    m[1].metric("Pending", sum(r["status"] == "Pending" for r in rows))
    m[2].metric("Approved", sum(r["status"] == "Approved" for r in rows))
    m[3].metric("Units requested", sum(int(p["qty"]) for r in rows for p in products_of(r["data"])))
    if not rows:
        st.info("No requests yet. Share the app link; each submitted request appears here.")
        return
    a, b = st.columns([3, 1])
    q = a.text_input("Search", key="adm_q", placeholder="Company, SKU, reference or order number").strip().lower()
    status_filter = b.selectbox("Status", ["All", "Pending", "Approved", "Rejected"], key="adm_status")

    def matches(r: dict) -> bool:
        d = r["data"]
        hay = " ".join([r["ref"], d.get("order_no") or "", d["seller"].get("company") or "", d["end"].get("company") or "",
                        " ".join(p["sku"] for p in products_of(d))]).lower()
        return (status_filter == "All" or r["status"] == status_filter) and (not q or q in hay)

    shown = [r for r in rows if matches(r)]
    st.dataframe([{
        "Submitted": r["created_at"][:16].replace("T", " "), "Reference": r["ref"],
        "Seller": r["data"]["seller"].get("company"), "End user": r["data"]["end"].get("company"),
        "Products": ", ".join(p["sku"] for p in products_of(r["data"])),
        "Units": sum(int(p["qty"]) for p in products_of(r["data"])),
        "Est. sales": fmt_date(r["data"].get("sales_date")), "Submitted by": r["user_email"], "Status": r["status"],
    } for r in shown], hide_index=True, use_container_width=True)
    st.download_button("Export to Excel", export_workbook(shown or rows),
                       file_name=f"{TITLE} requests {date.today():%Y-%m-%d}.xlsx")
    if not shown:
        st.caption("No matching requests. Change the search or the status filter.")
        return

    st.subheader("Open a request")
    by_ref = {r["ref"]: r for r in shown}
    ref = st.selectbox("Request", list(by_ref), key="adm_sel",
                       format_func=lambda x: f"{x} · {by_ref[x]['data']['seller'].get('company')} → "
                                             f"{by_ref[x]['data']['end'].get('company')} · {by_ref[x]['status']}")
    r = by_ref[ref]
    d = r["data"]
    status_badge(r["status"])
    c1, c2 = st.columns(2)
    with c1, st.container(border=True):
        st.markdown("**Seller**")
        kv(party_rows(d["seller"], True))
    with c2, st.container(border=True):
        st.markdown("**End user**")
        kv(party_rows(d["end"], False))
    with st.container(border=True):
        st.markdown("**Deal**")
        kv([("Submitted by", r["user_email"]), ("Intended use", d.get("use"))]
           + [(f"Product {n + 1}", f"{p['sku']} ({SKU_NO.get(p['sku'], '')}) × {p['qty']}")
              for n, p in enumerate(products_of(d))]
           + [("Estimated sales date", fmt_date(d.get("sales_date"))), ("Project scope", d.get("scope")),
              ("Order number", d.get("order_no") or "—")])
    with st.container(border=True):
        new_status = st.radio("Status", ["Pending", "Approved", "Rejected"], horizontal=True,
                              index=["Pending", "Approved", "Rejected"].index(r["status"]), key=f"adm_st_{ref}")
        x, y = st.columns(2)
        if x.button("Save status", type="primary", key=f"save_{ref}", disabled=new_status == r["status"]):
            updated = store.set_status(user["email"], ref, new_status)
            note = ""
            if new_status != "Pending" and SMTP.enabled:
                try:
                    subject, text_body, html_body = mailer.status_message(updated, APP_URL)
                    mailer.send(SMTP, [updated["user_email"]], subject, text_body, html_body)
                    note = f" {updated['user_email']} has been emailed."
                except Exception:
                    note = " The email to the submitter couldn't be sent."
            st.toast(f"Marked {new_status.lower()}.{note}")
            st.rerun()
        y.download_button("Download Excel", request_workbook(TEMPLATE, d, ref, r["user_email"]),
                          file_name=excel_name(ref), key=f"adm_dl_{ref}")
    with st.expander("Delete this request"):
        sure = st.checkbox("I want to delete this request permanently", key=f"del_ok_{ref}")
        if st.button("Delete", disabled=not sure, key=f"del_{ref}"):
            store.delete(user["email"], ref)
            st.toast(f"Request {ref} deleted.")
            st.rerun()


# ---------------------------------------------------------------- main
def main() -> None:
    init_state()
    st.logo(str(LOGO), size="large")
    user = current_user()
    if not user:
        page_sign_in()
        return
    if not domain_ok(user["email"]):
        st.error(f"Sign in with your work email ({', '.join('@' + d for d in ALLOWED_DOMAINS)}).")
        if st.button("Sign out"):
            sign_out()
        return
    admin = store.is_admin(user["email"])
    if ss.view == "admin" and not admin:
        ss.view = "form"

    with st.sidebar:
        st.caption(f"Signed in as {user['email']}")
        st.button("New request", on_click=set_view, args=("form",), use_container_width=True)
        if admin:
            st.button("All requests", on_click=set_view, args=("admin",), use_container_width=True)
        else:
            news = sum(r["status"] != r["seen_status"] for r in store.mine(user["email"]))
            st.button(f"My requests{f' ({news} new)' if news else ''}", on_click=set_view, args=("mine",),
                      use_container_width=True)
        if st.button("Sign out", use_container_width=True, type="tertiary"):
            sign_out()

    try:
        if ss.view == "admin":
            page_admin(user)
        elif ss.view == "mine":
            page_mine(user)
        elif ss.step == -1:
            page_welcome(user)
        elif ss.step == 5 and ss.done:
            page_done(user)
        elif ss.step == 4:
            page_review(user)
        else:
            page_step(max(0, min(ss.step, 3)))
    except NotAllowed:
        st.error("You don't have access to this.")


main()
