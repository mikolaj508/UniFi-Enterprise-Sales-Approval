# UniFi Enterprise Sales Approval (Python / Streamlit)

Aplikacja do zgłaszania sprzedaży produktów UniFi Enterprise, napisana w całości w Pythonie (Streamlit).

- Formularz krok po kroku, jak w pliku Excel: Intended Product Use → Seller → End-User → Deal → przegląd. Wszystkie pola wymagane, numer zamówienia opcjonalny.
- Logowanie kontem **Microsoft** lub **Google** (wbudowane `st.login`), na testy także tryb demo.
- Każdy widzi tylko swoje zgłoszenia i statusy (**My requests**), admin widzi wszystkie (**All requests**).
- Po zgłoszeniu zespół dostaje e-mail z **oryginalnym szablonem Excel** wypełnionym odpowiedziami.
- Po zmianie statusu zgłaszający dostaje e-mail z decyzją.

## Struktura

| Plik | Co robi |
| --- | --- |
| `app.py` | ekrany aplikacji (Streamlit) |
| `esa/validation.py` | reguły pól (wymagane, format WWW, e-mail, telefon, data) |
| `esa/excel.py` | wypełnianie `templates/ESA_Template.xlsx` i eksport wszystkich zgłoszeń |
| `esa/store.py` | baza zgłoszeń (SQLite lokalnie, Postgres w chmurze) i uprawnienia |
| `esa/mailer.py` | wysyłka maili przez SMTP |
| `esa/reference.py` | listy wyboru; lista SKU jest czytana z szablonu Excel |
| `templates/ESA_Template.xlsx` | Twój oryginalny plik, służy jako szablon |
| `.streamlit/config.toml` | kolory i wygląd |
| `.streamlit/secrets.toml.example` | wzór ustawień (adresy, poczta, logowanie) |
| `tests/` | testy automatyczne |

---

## 1. Uruchomienie na swoim komputerze (ok. 5 min)

Potrzebny Python 3.11 lub nowszy.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate     macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .streamlit/secrets.toml.example .streamlit/secrets.toml      # Windows: copy ...
streamlit run app.py
```

W `.streamlit/secrets.toml` wpisz swój adres w `admin_emails`. Aplikacja otworzy się pod `http://localhost:8501`. W trybie demo logujesz się, wpisując dowolny e-mail. Wpisz swój adres, żeby zobaczyć widok admina, a inny, żeby zobaczyć widok zgłaszającego.

Testy:

```bash
pip install -r requirements-dev.txt
pytest
```

## 2. Poczta (Gmail z prywatnego konta)

1. Na koncie Google włącz weryfikację dwuetapową.
2. Utwórz **hasło aplikacji**: [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords).
3. W sekcji `[smtp]` wpisz: `host = "smtp.gmail.com"`, `port = 465`, `user` = Twój Gmail, `password` = hasło aplikacji, `from` = `"UniFi Enterprise Approval <twoj@gmail.com>"`.
4. W `notify_to` wpisz, kto ma dostawać plik Excel po zgłoszeniu.

Inne skrzynki działają tak samo, jeśli udostępniają SMTP (np. port 587 z STARTTLS). Gdy mail się nie wyśle, zgłoszenie i tak zostaje zapisane, a aplikacja pokazuje ostrzeżenie.

## 3. Logowanie kontem Microsoft

1. [portal.azure.com](https://portal.azure.com) → **Microsoft Entra ID → App registrations → New registration**.
2. Supported account types:
   - pokaz z prywatnego konta: **Personal Microsoft accounts only** (outlook.com, hotmail.com),
   - konta firmowe EET: **Accounts in this organizational directory only**. Może wymagać zgody IT.
3. Redirect URI, platforma **Web**: `http://localhost:8501/oauth2callback`. Po wdrożeniu dodaj też `https://TWOJA-APLIKACJA.streamlit.app/oauth2callback`.
4. **Certificates & secrets → New client secret**: skopiuj wartość (Value).
5. W `secrets.toml` odkomentuj `[auth]` i `[auth.microsoft]`:
   - `client_id` = Application (client) ID,
   - `client_secret` = skopiowana wartość,
   - `server_metadata_url`: dla kont prywatnych `https://login.microsoftonline.com/consumers/v2.0/.well-known/openid-configuration`, dla jednej firmy zamień `consumers` na Tenant ID,
   - `cookie_secret`: dowolny długi losowy ciąg, np. wynik `python -c "import secrets; print(secrets.token_hex(32))"`.
6. Ustaw `demo_login = false`.

Google działa tak samo: [console.cloud.google.com](https://console.cloud.google.com) → **APIs & Services → Credentials → OAuth client ID** (Web application), ten sam Redirect URI, sekcja `[auth.google]`. Gdy ustawisz oba, na ekranie logowania pojawią się dwa przyciski.

Szczegóły: [Streamlit – Microsoft Entra](https://docs.streamlit.io/develop/tutorials/authentication/microsoft), [Streamlit – st.login](https://docs.streamlit.io/develop/api-reference/user/st.login).

## 4. GitHub

```bash
git init
git add .
git commit -m "UniFi Enterprise Sales Approval (Streamlit)"
git branch -M main
git remote add origin https://github.com/TWOJ_LOGIN/unifi-esa-streamlit.git
git push -u origin main
```

Plik `.streamlit/secrets.toml` jest w `.gitignore` i **nie** trafi do repozytorium. Hasła i klucze wpisujesz tylko lokalnie i w ustawieniach hostingu.

## 5. Publikacja: Streamlit Community Cloud (darmowe)

1. [share.streamlit.io](https://share.streamlit.io) → zaloguj się GitHubem → **Create app** i wskaż aplikację z GitHuba.
2. Wybierz repozytorium, branch `main`, plik `app.py`.
3. **Advanced settings**: Python 3.12 lub 3.13, a w polu **Secrets** wklej zawartość swojego `secrets.toml`. Zmień `redirect_uri` i `app_url` na adres aplikacji.
4. **Deploy**. Adres będzie w formie `https://….streamlit.app`. Dopisz go w Azure jako Redirect URI (krok 3).

**Ważne: baza w chmurze.** Na Community Cloud plik SQLite znika przy każdym restarcie aplikacji. Do pokazu, w którym zgłoszenia mają przetrwać, załóż darmową bazę Postgres i wpisz jej adres w `database_url`:

- [Supabase](https://supabase.com): Project Settings → Database → Connection string (URI),
- albo [Neon](https://neon.tech): Connection string.

Tabela tworzy się sama przy pierwszym uruchomieniu.

Alternatywy hostingu z własnym serwerem Pythona: Render, Railway, Azure App Service. Komenda startowa: `streamlit run app.py --server.port $PORT --server.address 0.0.0.0`.

## 6. Test przed pokazem

- [ ] Zaloguj się jako admin (adres z `admin_emails`). W menu po lewej widać **All requests**.
- [ ] W drugiej przeglądarce zaloguj się innym kontem i wyślij zgłoszenie z 2 produktami.
- [ ] Na adres z `notify_to` przyszedł mail z plikiem `ESA-….xlsx` w układzie oryginalnego szablonu.
- [ ] Jako admin otwórz zgłoszenie, ustaw **Approved** i kliknij **Save status**. Zgłaszający dostaje mail.
- [ ] Zgłaszający widzi komunikat na stronie startowej i oznaczenie **Updated** w **My requests**.

## Zmiany na później

- **Nowy SKU:** dopisz go w `templates/ESA_Template.xlsx` w tabeli „Enterprise SKU” (kolumny B i C). Formularz sam go pokaże.
- **Kolory:** `.streamlit/config.toml`.
- **Nowy admin:** dopisz adres w `admin_emails` w sekretach.

## Bezpieczeństwo i dane

- Uprawnienia sprawdza kod w `esa/store.py` przy każdej operacji, a nie tylko ukryte przyciski.
- Hasła i klucze są tylko w sekretach, nigdy w repozytorium.
- Na pokaz używaj danych testowych. Zanim trafią tu prawdziwe dane klientów, uzgodnij to z IT i osobą odpowiedzialną za RODO.
