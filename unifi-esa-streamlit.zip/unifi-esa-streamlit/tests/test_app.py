"""End-to-end tests of the Streamlit screens (headless, with demo sign-in, local SQLite and a local SMTP server)."""

from datetime import date, timedelta

from streamlit.testing.v1 import AppTest

from conftest import ROOT
from esa.store import Store, engine_for


def make_app(tmp_path, port, user):
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60)
    at.secrets["app"] = {"demo_login": True, "admin_emails": ["boss@eetgroup.com"], "notify_to": ["team@example.com"],
                         "database_url": f"sqlite:///{tmp_path}/app.db", "allowed_domains": ["eetgroup.com"]}
    at.secrets["smtp"] = {"host": "127.0.0.1", "port": port, "from": "ESA <esa@example.com>", "security": "none"}
    at.run()
    at.text_input(key="demo_email").input(user)
    at.button(key="demo_continue").click().run()
    return at


def click(at, label):
    at.button[[b.label for b in at.button].index(label)].click().run()
    assert not at.exception, [e.value for e in at.exception]


def fill_party(at, p, seller):
    values = {"company": "Acme", "website": "www.acme.pl", "street": "Prosta 1", "state": "Maz", "city": "Warszawa",
              "postal": "00-001", "contact": "Jan", "phone": "+48 22 123 45 67", "email": "jan@acme.pl"}
    for k, v in values.items():
        at.text_input(key=f"f_{p}_{k}").input(v)
    at.selectbox(key=f"f_{p}_country").set_value("Poland")
    if seller:
        at.radio(key="f_s_employees").set_value("11-50")
        at.radio(key="f_s_offering").set_value("System Integrator")


def test_outside_domain_is_refused(tmp_path, smtp_server):
    at = make_app(tmp_path, smtp_server[1], "someone@gmail.com")
    assert any("work email" in e.value for e in at.error)


def test_full_flow(tmp_path, smtp_server):
    inbox, port = smtp_server
    at = make_app(tmp_path, port, "anna@eetgroup.com")
    click(at, "Start request")

    click(at, "Continue")                                    # nothing chosen -> stays, shows errors
    assert at.session_state.step == 0 and at.error
    at.radio(key="f_use").set_value("Lab Setup")
    click(at, "Continue")

    fill_party(at, "s", seller=True)
    click(at, "Continue")
    assert at.session_state.step == 2
    fill_party(at, "e", seller=False)
    click(at, "Continue")

    at.selectbox(key="f_sku_0").set_value("ECS-24-PoE")
    at.number_input(key="f_qty_0").set_value(4)
    click(at, "＋ Add another product")
    at.selectbox(key="f_sku_1").set_value("E7")
    at.date_input(key="f_date").set_value(date.today() + timedelta(days=20))
    at.text_area(key="f_scope").input("Two office sites with a fiber core and 40 access points.")
    click(at, "Review request")
    assert at.session_state.step == 4

    click(at, "Edit")                                        # first Edit = Intended Product Use
    assert at.session_state.step == 0 and at.radio(key="f_use").value == "Lab Setup"   # answers kept
    for _ in range(4):
        click(at, "Continue" if at.session_state.step < 3 else "Review request")
    at.text_input(key="f_order").input("PO-77")
    click(at, "Submit request")
    assert at.session_state.step == 5
    ref = at.session_state.done["ref"]
    assert at.session_state.done["mailed"] is True

    rcpt, msg = inbox.messages[-1]
    assert rcpt == ["team@example.com"] and ref in msg["Subject"]
    assert any(p.get_filename() and p.get_filename().endswith(".xlsx") for p in msg.walk())

    store = Store(engine_for(f"sqlite:///{tmp_path}/app.db"), ["boss@eetgroup.com"])
    row = store.mine("anna@eetgroup.com")[0]
    assert row["ref"] == ref and row["data"]["order_no"] == "PO-77"
    assert [p["sku"] for p in row["data"]["products"]] == ["ECS-24-PoE", "E7"]

    # a normal user cannot open the admin list
    at.session_state.view = "admin"
    at.run()
    assert not any(h.value == "All requests" for h in at.header)

    # admin approves -> the submitter is emailed
    boss = make_app(tmp_path, port, "boss@eetgroup.com")
    click(boss, "All requests")
    assert any(m.value == "1" for m in boss.metric)
    boss.radio(key=f"adm_st_{ref}").set_value("Approved").run()   # choosing a status enables Save
    click(boss, "Save status")
    rcpt, msg = inbox.messages[-1]
    assert rcpt == ["anna@eetgroup.com"] and msg["Subject"].startswith("Approved")

    # the submitter sees the update once
    anna = make_app(tmp_path, port, "anna@eetgroup.com")
    assert any("was approved" in i.value for i in anna.info)
    click(anna, "My requests (1 new)")
    assert any("Updated" in e.label for e in anna.expander)
    assert store.mine("anna@eetgroup.com")[0]["seen_status"] == "Approved"


def test_microsoft_sign_in_replaces_demo(tmp_path):
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60)
    at.secrets["app"] = {"database_url": f"sqlite:///{tmp_path}/app.db"}
    at.secrets["auth"] = {"redirect_uri": "http://localhost:8501/oauth2callback", "cookie_secret": "x",
                          "microsoft": {"client_id": "a", "client_secret": "b",
                                        "server_metadata_url": "https://login.microsoftonline.com/consumers/v2.0/.well-known/openid-configuration"}}
    at.run()
    assert [b.label for b in at.button] == ["Sign in with Microsoft"]
    assert not [t for t in at.text_input if t.key == "demo_email"]
