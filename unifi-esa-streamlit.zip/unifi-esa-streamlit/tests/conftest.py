import email
import socket
import sys
from datetime import date, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TEMPLATE = ROOT / "templates" / "ESA_Template.xlsx"


def sample_request(n_products: int = 2) -> dict:
    party = {"company": "Acme Sp. z o.o.", "website": "www.acme.pl", "country": "Poland", "street": "Prosta 1",
             "state": "Mazowieckie", "city": "Warszawa", "postal": "00-001", "contact": "Jan Kowalski",
             "phone": "+48 22 123 45 67", "email": "jan@acme.pl"}
    skus = ["ECS-24-PoE", "E7", "EFG", "ENVR", "UXG-Enterprise"]
    return {
        "use": "Lab Setup",
        "seller": party | {"employees": "11-50", "offering": "System Integrator", "offering_other": ""},
        "end": party | {"company": "End Customer GmbH", "country": "Germany", "email": "it@end.de"},
        "products": [{"sku": skus[i], "qty": i + 2} for i in range(n_products)],
        "sales_date": date.today() + timedelta(days=30),
        "scope": "Two office sites with a fiber core and 40 access points.",
        "order_no": "PO-1",
    }


class Inbox:
    def __init__(self):
        self.messages = []

    async def handle_DATA(self, server, session, envelope):
        self.messages.append((envelope.rcpt_tos, email.message_from_bytes(envelope.content)))
        return "250 OK"


@pytest.fixture
def smtp_server():
    from aiosmtpd.controller import Controller
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    inbox = Inbox()
    ctl = Controller(inbox, hostname="127.0.0.1", port=port)
    ctl.start()
    yield inbox, port
    ctl.stop()
