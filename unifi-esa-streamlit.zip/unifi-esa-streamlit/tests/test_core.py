from datetime import date, timedelta
from io import BytesIO

import pytest
from openpyxl import load_workbook

from conftest import TEMPLATE, sample_request
from esa import mailer
from esa.excel import export_workbook, request_workbook
from esa.reference import countries, load_skus
from esa.store import NotAllowed, Store, engine_for
from esa.validation import step_errors

TODAY = date.today()


def test_skus_come_from_template():
    skus = dict(load_skus(TEMPLATE))
    assert len(skus) == 52
    assert skus["ECS-24-PoE"] == "W129015507"
    assert "Poland" in countries()


def test_every_field_is_required():
    empty = {"use": "", "seller": {}, "end": {}, "products": [{"sku": None, "qty": 1}], "sales_date": None, "scope": ""}
    assert set(step_errors(0, empty, TODAY)) == {"use"}
    assert {"company", "website", "country", "phone", "email", "employees", "offering"} <= set(step_errors(1, empty, TODAY))
    assert "employees" not in step_errors(2, empty, TODAY)
    assert {"sku0", "sales_date", "scope"} <= set(step_errors(3, empty, TODAY))
    ok = sample_request()
    assert all(not step_errors(i, ok, TODAY) for i in range(4))


@pytest.mark.parametrize("field,value,expected", [
    ("website", "acme", "website"), ("email", "jan@", "email"), ("phone", "22 123 45 67", "phone"),
    ("phone", "+48 12", "phone"),
])
def test_bad_formats(field, value, expected):
    req = sample_request()
    req["seller"][field] = value
    assert expected in step_errors(1, req, TODAY)


def test_deal_rules():
    req = sample_request()
    req["products"].append({"sku": "ECS-24-PoE", "qty": 1})
    req["sales_date"] = TODAY - timedelta(days=1)
    errs = step_errors(3, req, TODAY)
    assert "sku2" in errs and "sales_date" in errs
    req = sample_request()
    req["seller"]["offering"] = "Other"
    assert "offering_other" in step_errors(1, req, TODAY)


def test_excel_fills_original_template():
    wb = load_workbook(BytesIO(request_workbook(TEMPLATE, sample_request(2), "ESA-TEST-0001", "anna@eetgroup.com")))
    ws = wb.worksheets[0]
    assert ws["C2"].value == "ESA-TEST-0001"
    assert ws["B4"].value == "Lab Setup"
    assert ws["C7"].value == "Acme Sp. z o.o." and ws["C14"].value == "11-50" and ws["C18"].value == "jan@acme.pl"
    assert ws["C21"].value == "End Customer GmbH" and ws["C30"].value == "it@end.de"
    assert (ws["C33"].value, ws["C34"].value, ws["C35"].value, ws["C36"].value) == ("ECS-24-PoE", 2, "E7", 3)
    assert ws["C37"].value is None
    assert ws["B39"].value == "Estimated Sales Date" and ws["C39"].value.date() == TODAY + timedelta(days=30)
    assert ws["C42"].value == "PO-1" and ws["C43"].value == "anna@eetgroup.com"
    assert ws["B48"].value.strip() == "Enterprise SKU"          # product table still in place


def test_excel_adds_rows_for_more_than_three_products():
    ws = load_workbook(BytesIO(request_workbook(TEMPLATE, sample_request(5), "ESA-TEST-0002"))).worksheets[0]
    assert [ws.cell(33 + 2 * i, 3).value for i in range(5)] == ["ECS-24-PoE", "E7", "EFG", "ENVR", "UXG-Enterprise"]
    assert ws["B41"].value == "Enterprise Product" and ws["C42"].value == 6
    assert ws["B43"].value == "Estimated Sales Date" and ws["B44"].value == "Description of Project Scope"
    assert ws["B52"].value.strip() == "Enterprise SKU"          # pushed down by 4 rows


def test_store_access_rules(tmp_path):
    store = Store(engine_for(f"sqlite:///{tmp_path}/t.db"), ["boss@eetgroup.com"])
    a = store.add("anna@eetgroup.com", "Anna", sample_request())
    p = store.add("Piotr@eetgroup.com", "Piotr", sample_request(1))
    assert [r["ref"] for r in store.mine("anna@eetgroup.com")] == [a["ref"]]
    assert store.mine("piotr@eetgroup.com")[0]["ref"] == p["ref"]
    with pytest.raises(NotAllowed):
        store.all("anna@eetgroup.com")
    with pytest.raises(NotAllowed):
        store.set_status("anna@eetgroup.com", a["ref"], "Approved")
    with pytest.raises(NotAllowed):
        store.get_for("anna@eetgroup.com", p["ref"])
    with pytest.raises(NotAllowed):
        store.delete("anna@eetgroup.com", p["ref"])
    assert len(store.all("BOSS@eetgroup.com")) == 2
    store.set_status("boss@eetgroup.com", a["ref"], "Approved")
    mine = store.mine("anna@eetgroup.com")[0]
    assert (mine["status"], mine["seen_status"]) == ("Approved", "Pending")
    store.mark_seen("piotr@eetgroup.com", [a["ref"]])           # someone else cannot mark it
    assert store.mine("anna@eetgroup.com")[0]["seen_status"] == "Pending"
    store.mark_seen("anna@eetgroup.com", [a["ref"]])
    assert store.mine("anna@eetgroup.com")[0]["seen_status"] == "Approved"
    assert export_workbook(store.all("boss@eetgroup.com"))[:2] == b"PK"


def test_mail_with_attachment(smtp_server):
    inbox, port = smtp_server
    cfg = mailer.SmtpConfig(host="127.0.0.1", port=port, sender="ESA <esa@example.com>", security="none")
    row = {"ref": "ESA-TEST-0003", "user_email": "anna@eetgroup.com", "status": "Approved",
           "data": sample_request() | {"sales_date": "2027-01-15"}}
    row["data"]["seller"]["company"] = "Acme <script>"
    subject, text_body, html_body = mailer.new_request_message(row, "https://app.example")
    mailer.send(cfg, ["team@example.com"], subject, text_body, html_body,
                [("ESA-TEST-0003.xlsx", request_workbook(TEMPLATE, row["data"], row["ref"]))])
    rcpt, msg = inbox.messages[0]
    assert rcpt == ["team@example.com"] and "ESA-TEST-0003" in msg["Subject"]
    parts = {p.get_filename(): p for p in msg.walk() if p.get_filename()}
    assert parts["ESA-TEST-0003.xlsx"].get_payload(decode=True)[:2] == b"PK"
    html = next(p for p in msg.walk() if p.get_content_type() == "text/html").get_payload(decode=True).decode()
    assert "&lt;script&gt;" in html and "<script>" not in html
