"""Email over SMTP (Gmail, Outlook.com, company server ...)."""

from __future__ import annotations

import smtplib
import ssl
from dataclasses import dataclass
from email.message import EmailMessage
from html import escape

from .excel import products_of

XLSX_TYPE = ("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@dataclass
class SmtpConfig:
    host: str = ""
    port: int = 465
    user: str = ""
    password: str = ""
    sender: str = ""          # "UniFi Approval <you@gmail.com>"
    security: str = ""        # "ssl" | "starttls" | "none"; empty = from port (465 ssl, 587 starttls)

    @property
    def enabled(self) -> bool:
        return bool(self.host and self.sender)

    @classmethod
    def from_dict(cls, d: dict | None) -> "SmtpConfig":
        d = dict(d or {})
        return cls(host=d.get("host", ""), port=int(d.get("port", 465)), user=d.get("user", ""),
                   password=d.get("password", ""), sender=d.get("from", ""), security=d.get("security", ""))


def send(cfg: SmtpConfig, to: list[str], subject: str, text_body: str, html_body: str | None = None,
         attachments: list[tuple[str, bytes]] = ()) -> None:
    if not cfg.enabled:
        raise RuntimeError("Email is not configured (smtp.host and smtp.from in secrets).")
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = cfg.sender, ", ".join(to), subject
    msg.set_content(text_body)
    if html_body:
        msg.add_alternative(html_body, subtype="html")
    for name, data in attachments:
        msg.add_attachment(data, maintype=XLSX_TYPE[0], subtype=XLSX_TYPE[1], filename=name)

    mode = cfg.security or {465: "ssl", 587: "starttls"}.get(cfg.port, "none")
    ctx = ssl.create_default_context()
    if mode == "ssl":
        server = smtplib.SMTP_SSL(cfg.host, cfg.port, context=ctx, timeout=30)
    else:
        server = smtplib.SMTP(cfg.host, cfg.port, timeout=30)
    with server:
        if mode == "starttls":
            server.starttls(context=ctx)
        if cfg.user:
            server.login(cfg.user, cfg.password)
        server.send_message(msg)


# ----- message content -----
def _table(rows: list[tuple[str, str]]) -> str:
    cells = "".join(
        f'<tr><td style="color:#6e6e73;vertical-align:top;white-space:nowrap">{escape(k)}</td>'
        f'<td style="white-space:pre-wrap">{escape(str(v or ""))}</td></tr>' for k, v in rows)
    return f'<table cellpadding="6" style="border-collapse:collapse;font:14px Arial,sans-serif">{cells}</table>'


def _products(req: dict) -> str:
    return "\n".join(f"{p['sku']} × {p['qty']}" for p in products_of(req))


def new_request_message(row: dict, app_url: str = "") -> tuple[str, str, str]:
    d = row["data"]
    rows = [("Reference", row["ref"]), ("Submitted by", row["user_email"]), ("Intended use", d.get("use")),
            ("Seller", f"{d['seller'].get('company')} ({d['seller'].get('country')})"),
            ("End user", f"{d['end'].get('company')} ({d['end'].get('country')})"),
            ("Products", _products(d)), ("Estimated sales date", d.get("sales_date")),
            ("Order number", d.get("order_no") or "Not provided"), ("Project scope", d.get("scope"))]
    subject = f"New UniFi Enterprise request {row['ref']} – {d['seller'].get('company')}"
    link = f"\n\n{app_url}" if app_url else ""
    text_body = "A new UniFi Enterprise sales approval request was submitted. The completed form is attached.\n\n" + \
        "\n".join(f"{k}: {v or ''}" for k, v in rows) + link
    html_body = ("<p>A new UniFi Enterprise sales approval request was submitted. The completed form is attached.</p>"
                 + _table(rows) + (f'<p><a href="{escape(app_url)}">Open the app</a></p>' if app_url else ""))
    return subject, text_body, html_body


def status_message(row: dict, app_url: str = "") -> tuple[str, str, str]:
    d, status = row["data"], row["status"]
    rows = [("Reference", row["ref"]), ("Status", status), ("Seller", d["seller"].get("company")),
            ("End user", d["end"].get("company")), ("Products", _products(d))]
    subject = f"{status}: UniFi Enterprise request {row['ref']}"
    intro = f"Your UniFi Enterprise sales approval request {row['ref']} was {status.lower()}."
    link = f"\n\n{app_url}" if app_url else ""
    text_body = intro + "\n\n" + "\n".join(f"{k}: {v or ''}" for k, v in rows) + link
    html_body = (f"<p>{escape(intro)}</p>" + _table(rows)
                 + (f'<p><a href="{escape(app_url)}">See your requests</a></p>' if app_url else ""))
    return subject, text_body, html_body
