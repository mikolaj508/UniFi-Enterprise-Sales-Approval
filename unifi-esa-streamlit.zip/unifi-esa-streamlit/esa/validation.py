"""Field rules. Every field is required except the order number."""

from __future__ import annotations

import re
from datetime import date

WEBSITE_RX = re.compile(r"^(https?://)?([a-z0-9-]+\.)+[a-z]{2,}(/\S*)?$", re.I)
EMAIL_RX = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")
PHONE_RX = re.compile(r"^\+[\d\s().\-/]+$")

# (key, label, kind) in the order of the Excel template
COMPANY_FIELDS = [("company", "Company Name", "text"), ("website", "Company Website", "website")]
ADDRESS_FIELDS = [
    ("country", "Country", "country"),
    ("street", "Street Address", "text"),
    ("state", "State / Province", "text"),
    ("city", "City", "text"),
    ("postal", "Postal Code", "text"),
]
CONTACT_FIELDS = [
    ("contact", "Contact Name", "text"),
    ("phone", "Contact Phone Number", "phone"),
    ("email", "Contact Email Address", "email"),
]
PARTY_FIELDS = COMPANY_FIELDS + ADDRESS_FIELDS + CONTACT_FIELDS


def check_field(label: str, kind: str, value) -> str:
    v = "" if value is None else str(value).strip()
    if not v:
        return "Choose a country." if kind == "country" else f"Enter the {label.lower()}."
    if kind == "website" and not WEBSITE_RX.match(v):
        return "Enter a web address such as www.company.com."
    if kind == "email" and not EMAIL_RX.match(v):
        return "Enter an email address such as name@company.com."
    if kind == "phone":
        if not v.startswith("+"):
            return "Start with the country code, for example +48."
        if len(re.sub(r"\D", "", v)) < 8 or not PHONE_RX.match(v):
            return "Enter a full phone number with digits only, for example +48 22 123 45 67."
    return ""


def party_errors(p: dict, seller: bool) -> dict[str, str]:
    errs = {k: m for k, label, kind in PARTY_FIELDS if (m := check_field(label, kind, p.get(k)))}
    if seller:
        if not p.get("employees"):
            errs["employees"] = "Choose the number of employees."
        if not p.get("offering"):
            errs["offering"] = "Choose what your company offers."
        elif p["offering"] == "Other" and not str(p.get("offering_other") or "").strip():
            errs["offering_other"] = "Describe what your company offers."
    return errs


def deal_errors(d: dict, today: date) -> dict[str, str]:
    errs: dict[str, str] = {}
    seen: set[str] = set()
    for i, p in enumerate(d.get("products") or []):
        sku = p.get("sku")
        if not sku:
            errs[f"sku{i}"] = "Choose a product."
        elif sku in seen:
            errs[f"sku{i}"] = "This product is already listed. Change the quantity on the first line instead."
        else:
            seen.add(sku)
        q = p.get("qty")
        if not isinstance(q, int) or q < 1:
            errs[f"qty{i}"] = "Enter a whole number of 1 or more."
    sd = d.get("sales_date")
    if not sd:
        errs["sales_date"] = "Enter the estimated sales date."
    elif sd < today:
        errs["sales_date"] = "Choose today or a later date."
    scope = str(d.get("scope") or "").strip()
    if len(scope) < 20:
        errs["scope"] = "Add a little more detail (at least 20 characters)." if scope else "Describe the project scope."
    return errs


def step_errors(step: int, req: dict, today: date) -> dict[str, str]:
    if step == 0:
        return {} if req.get("use") else {"use": "Choose how the products will be used."}
    if step == 1:
        return party_errors(req["seller"], seller=True)
    if step == 2:
        return party_errors(req["end"], seller=False)
    if step == 3:
        return deal_errors(req, today)
    return {}
