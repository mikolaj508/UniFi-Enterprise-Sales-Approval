"""Where requests are kept: SQLite file locally, any Postgres (e.g. Supabase, Neon) in the cloud.

Access rules live here, not only in the screens: people read only their own requests,
admins read and change all of them.
"""

from __future__ import annotations

import json
import secrets
import string
from datetime import date, datetime, timezone

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

DDL = """
CREATE TABLE IF NOT EXISTS esa_requests (
    ref          VARCHAR(40)  PRIMARY KEY,
    user_email   VARCHAR(320) NOT NULL,
    user_name    VARCHAR(200),
    data         TEXT         NOT NULL,
    status       VARCHAR(20)  NOT NULL DEFAULT 'Pending',
    seen_status  VARCHAR(20)  NOT NULL DEFAULT 'Pending',
    status_at    VARCHAR(40),
    notified_at  VARCHAR(40),
    created_at   VARCHAR(40)  NOT NULL
)
"""
STATUSES = ("Pending", "Approved", "Rejected")


class NotAllowed(Exception):
    pass


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _json_default(v):
    if isinstance(v, (date, datetime)):
        return v.isoformat()
    raise TypeError(type(v))


def new_ref(today: date | None = None) -> str:
    d = today or date.today()
    tail = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(4))
    return f"ESA-{d:%y%m%d}-{tail}"


def engine_for(url: str | None) -> Engine:
    url = (url or "").strip() or "sqlite:///esa_requests.db"
    if url.startswith("postgres://"):
        url = "postgresql://" + url[len("postgres://"):]
    if url.startswith("postgresql://"):
        url = "postgresql+psycopg://" + url[len("postgresql://"):]
    return create_engine(url, pool_pre_ping=True)


class Store:
    def __init__(self, engine: Engine, admin_emails: list[str]):
        self.engine = engine
        self.admins = {e.strip().lower() for e in admin_emails if e.strip()}
        with engine.begin() as c:
            c.execute(text(DDL))

    # ----- helpers -----
    def is_admin(self, email: str | None) -> bool:
        return bool(email) and email.lower() in self.admins

    @staticmethod
    def _row(m) -> dict:
        r = dict(m)
        r["data"] = json.loads(r["data"])
        return r

    def _get(self, ref: str) -> dict | None:
        with self.engine.connect() as c:
            m = c.execute(text("SELECT * FROM esa_requests WHERE ref = :ref"), {"ref": ref}).mappings().first()
        return self._row(m) if m else None

    # ----- everyone -----
    def add(self, user_email: str, user_name: str, req: dict) -> dict:
        ref = new_ref()
        with self.engine.begin() as c:
            c.execute(text("""INSERT INTO esa_requests (ref, user_email, user_name, data, created_at)
                              VALUES (:ref, :email, :name, :data, :created)"""),
                      {"ref": ref, "email": user_email.lower(), "name": user_name or "",
                       "data": json.dumps(req, default=_json_default), "created": _now()})
        return self._get(ref)

    def mine(self, user_email: str) -> list[dict]:
        with self.engine.connect() as c:
            ms = c.execute(text("SELECT * FROM esa_requests WHERE user_email = :e ORDER BY created_at DESC"),
                           {"e": user_email.lower()}).mappings().all()
        return [self._row(m) for m in ms]

    def get_for(self, user_email: str, ref: str) -> dict:
        r = self._get(ref)
        if not r or not (r["user_email"] == user_email.lower() or self.is_admin(user_email)):
            raise NotAllowed(ref)
        return r

    def mark_seen(self, user_email: str, refs: list[str]) -> None:
        if not refs:
            return
        with self.engine.begin() as c:
            for ref in refs:
                c.execute(text("UPDATE esa_requests SET seen_status = status WHERE ref = :ref AND user_email = :e"),
                          {"ref": ref, "e": user_email.lower()})

    def mark_notified(self, ref: str) -> None:
        with self.engine.begin() as c:
            c.execute(text("UPDATE esa_requests SET notified_at = :t WHERE ref = :ref"), {"t": _now(), "ref": ref})

    # ----- admins only -----
    def all(self, actor_email: str) -> list[dict]:
        if not self.is_admin(actor_email):
            raise NotAllowed("all")
        with self.engine.connect() as c:
            ms = c.execute(text("SELECT * FROM esa_requests ORDER BY created_at DESC")).mappings().all()
        return [self._row(m) for m in ms]

    def set_status(self, actor_email: str, ref: str, status: str) -> dict:
        if not self.is_admin(actor_email):
            raise NotAllowed("set_status")
        if status not in STATUSES:
            raise ValueError(status)
        with self.engine.begin() as c:
            c.execute(text("UPDATE esa_requests SET status = :s, status_at = :t WHERE ref = :ref"),
                      {"s": status, "t": _now(), "ref": ref})
        return self._get(ref)

    def delete(self, actor_email: str, ref: str) -> None:
        if not self.is_admin(actor_email):
            raise NotAllowed("delete")
        with self.engine.begin() as c:
            c.execute(text("DELETE FROM esa_requests WHERE ref = :ref"), {"ref": ref})
