"""Fixed choices for the form. The product list is read from the Excel template,
so adding a SKU there (column B/C under "Enterprise SKU") adds it to the form."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import pycountry
from openpyxl import load_workbook

USES: list[tuple[str, str]] = [
    ("Installation and Managed Services", "You install the system and keep managing it for the end user."),
    ("Installation Only", "You install and hand over; the end user runs it."),
    ("Internal Use", "The products run in your own company network."),
    ("Lab Setup", "Testing, demo or training environment."),
]
EMPLOYEES = ["1-5", "6-10", "11-50", "51-100", "101-300", "300+"]
OFFERINGS = ["Managed Service Provider", "System Integrator", "Other"]
STATUSES = ["Pending", "Approved", "Rejected"]


@lru_cache(maxsize=4)
def load_skus(template_path: str | Path) -> list[tuple[str, str]]:
    """Return [(sku, number)] from the 'Enterprise SKU' table in the template, sorted by SKU."""
    ws = load_workbook(template_path, read_only=True).worksheets[0]
    skus: list[tuple[str, str]] = []
    in_table = False
    for b, c in ws.iter_rows(min_col=2, max_col=3, values_only=True):
        if not in_table:
            in_table = isinstance(b, str) and b.strip().lower() == "enterprise sku"
            continue
        if b is None or str(b).strip() == "":
            continue
        skus.append((str(b).strip(), "" if c is None else str(c).strip()))
    return sorted(skus, key=lambda s: s[0].lower())


@lru_cache(maxsize=1)
def countries() -> list[str]:
    names = {getattr(c, "common_name", None) or c.name for c in pycountry.countries}
    names.add("Kosovo")
    return sorted(names)
