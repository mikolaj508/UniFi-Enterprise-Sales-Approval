"""UniFi Enterprise Sales Approval: core logic (no Streamlit imports here, so it is easy to test)."""
