"""Excel files: one request filled into the original template, and an export of many requests."""

from __future__ import annotations

from copy import copy
from datetime import date, datetime
from io import BytesIO
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font

# Template layout (UI_Enterprise_SKU_Sales_Approval.xlsx): labels in column B, answers in column C.
SELLER_FIRST_ROW = 7      # Company Name .. Contact Email Address = rows 7-18
END_FIRST_ROW = 21        # rows 21-30
PRODUCT_FIRST_ROW = 33    # Enterprise Product / Quantity pairs, 3 pairs in the template
DATE_ROW = 39
SCOPE_ROW = 40


def offering_text(seller: dict) -> str:
    if seller.get("offering") == "Other":
        return f"Other: {str(seller.get('offering_other') or '').strip()}"
    return seller.get("offering") or ""


def products_of(req: dict) -> list[dict]:
    return [p for p in req.get("products") or [] if p.get("sku")]


def _as_date(v):
    if isinstance(v, (date, datetime)):
        return v
    try:
        return date.fromisoformat(str(v))
    except ValueError:
        return v


def request_workbook(template: str | Path, req: dict, ref: str, submitted_by: str = "") -> bytes:
    """Fill the original template with one request and return the .xlsx bytes."""
    wb = load_workbook(template)
    ws = wb.worksheets[0]

    ws["B2"], ws["C2"] = "Reference", ref
    ws["B4"] = req.get("use", "")

    s = req["seller"]
    seller_values = [s.get("company"), s.get("website"), s.get("country"), s.get("street"), s.get("state"),
                     s.get("city"), s.get("postal"), s.get("employees"), offering_text(s),
                     s.get("contact"), s.get("phone"), s.get("email")]
    for i, v in enumerate(seller_values):
        ws.cell(SELLER_FIRST_ROW + i, 3, v)

    e = req["end"]
    end_values = [e.get("company"), e.get("website"), e.get("country"), e.get("street"), e.get("state"),
                  e.get("city"), e.get("postal"), e.get("contact"), e.get("phone"), e.get("email")]
    for i, v in enumerate(end_values):
        ws.cell(END_FIRST_ROW + i, 3, v)

    products = products_of(req)
    extra = max(0, len(products) - 3)
    if extra:
        # Push the date, scope and the SKU table down to make room for more product lines.
        ws.insert_rows(DATE_ROW, amount=extra * 2)
    for i in range(max(3, len(products))):
        row = PRODUCT_FIRST_ROW + i * 2
        for r, label in ((row, "Enterprise Product"), (row + 1, "Quantity")):
            for col in (2, 3):
                src = ws.cell(PRODUCT_FIRST_ROW + (r - row), col)
                if r != src.row:
                    ws.cell(r, col)._style = copy(src._style)
            ws.cell(r, 2, label)
        p = products[i] if i < len(products) else None
        ws.cell(row, 3, p["sku"] if p else None)
        ws.cell(row + 1, 3, int(p["qty"]) if p else None)

    off = extra * 2
    d = ws.cell(DATE_ROW + off, 3, _as_date(req.get("sales_date")))
    d.number_format = "DD/MM/YYYY"
    sc = ws.cell(SCOPE_ROW + off, 3, req.get("scope", ""))
    sc.alignment = Alignment(wrap_text=True, vertical="top")
    ws.cell(SCOPE_ROW + off + 2, 2, "Order Number")
    ws.cell(SCOPE_ROW + off + 2, 3, req.get("order_no") or "")
    ws.cell(SCOPE_ROW + off + 3, 2, "Submitted by")
    ws.cell(SCOPE_ROW + off + 3, 3, submitted_by)

    out = BytesIO()
    wb.save(out)
    return out.getvalue()


def export_workbook(rows: list[dict]) -> bytes:
    """All requests in one file: sheet 'Requests' (one row each) and 'Product lines'."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Requests"
    party = ["Company Name", "Company Website", "Country", "Street Address", "State / Province", "City",
             "Postal Code", "Contact Name", "Contact Phone Number", "Contact Email Address"]
    head = (["Reference", "Submitted", "Status", "Submitted by", "Intended Product Use"]
            + [f"Seller – {x}" for x in party[:7]] + ["Seller – Total Number of Employees", "Seller – Company Offerings"]
            + [f"Seller – {x}" for x in party[7:]] + [f"End user – {x}" for x in party]
            + ["Products", "Total quantity", "Estimated Sales Date", "Description of Project Scope", "Order Number"])
    ws.append(head)
    lines = wb.create_sheet("Product lines")
    lines.append(["Reference", "Enterprise Product", "Quantity", "Status"])
    keys = ["company", "website", "country", "street", "state", "city", "postal"]
    contact = ["contact", "phone", "email"]
    for r in rows:
        req, s, e = r["data"], r["data"]["seller"], r["data"]["end"]
        prods = products_of(req)
        ws.append([r["ref"], r["created_at"][:16].replace("T", " "), r["status"], r["user_email"], req.get("use")]
                  + [s.get(k) for k in keys] + [s.get("employees"), offering_text(s)] + [s.get(k) for k in contact]
                  + [e.get(k) for k in keys + contact]
                  + ["; ".join(f"{p['sku']} × {p['qty']}" for p in prods), sum(int(p["qty"]) for p in prods),
                     req.get("sales_date"), req.get("scope"), req.get("order_no") or ""])
        for p in prods:
            lines.append([r["ref"], p["sku"], int(p["qty"]), r["status"]])
    for sheet in (ws, lines):
        for c in sheet[1]:
            c.font = Font(bold=True)
        for col in sheet.columns:
            sheet.column_dimensions[col[0].column_letter].width = 22
    out = BytesIO()
    wb.save(out)
    return out.getvalue()
