-- UniFi Enterprise Sales Approval: database schema and access rules
-- Run once in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run.
-- Safe to re-run: it drops and recreates the policies and functions it owns.

-- 1. Requests --------------------------------------------------------------
create table if not exists public.requests (
  id           uuid primary key default gen_random_uuid(),
  ref          text not null unique,                       -- e.g. ESA-261110-K3F9
  user_id      uuid not null default auth.uid() references auth.users(id) on delete cascade,
  user_email   text not null default (auth.jwt() ->> 'email'),
  data         jsonb not null,                             -- all form answers
  status       text not null default 'Pending' check (status in ('Pending','Approved','Rejected')),
  seen_status  text not null default 'Pending',            -- last status the submitter has seen
  status_at    timestamptz,
  notified_at  timestamptz,                                -- set when the team email was sent
  created_at   timestamptz not null default now()
);
create index if not exists requests_user_id_idx on public.requests (user_id);
create index if not exists requests_created_at_idx on public.requests (created_at desc);

-- 2. Admins (people who see and decide every request) -----------------------
create table if not exists public.app_admins (
  email text primary key
);
-- No policies on app_admins: nobody can read or change it through the API.
-- Manage it here in the SQL editor (see step 5).
alter table public.app_admins enable row level security;

create or replace function public.is_admin()
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.app_admins
    where lower(email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  );
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- 3. Row level security: admins see everything, everyone else only their own
alter table public.requests enable row level security;

drop policy if exists "read own or admin" on public.requests;
create policy "read own or admin" on public.requests
  for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

drop policy if exists "insert own pending" on public.requests;
create policy "insert own pending" on public.requests
  for insert to authenticated
  with check (
    user_id = auth.uid()
    and user_email = (auth.jwt() ->> 'email')
    and status = 'Pending'
    and seen_status = 'Pending'
    and status_at is null
    and notified_at is null
    -- Optional: only allow work emails. Uncomment and set your domain.
    -- and lower(auth.jwt() ->> 'email') like '%@eetgroup.com'
  );

drop policy if exists "admin update" on public.requests;
create policy "admin update" on public.requests
  for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin delete" on public.requests;
create policy "admin delete" on public.requests
  for delete to authenticated
  using (public.is_admin());

-- Submitters may only mark status updates on their own requests as seen.
create or replace function public.mark_seen(ids uuid[])
returns void
language sql security definer set search_path = public
as $$
  update public.requests
     set seen_status = status
   where id = any(ids) and user_id = auth.uid();
$$;
revoke all on function public.mark_seen(uuid[]) from public;
grant execute on function public.mark_seen(uuid[]) to authenticated;

-- 4. Live updates in the page (status changes appear without reloading) -----
do $$
begin
  alter publication supabase_realtime add table public.requests;
exception when duplicate_object then null;
end $$;

-- 5. Make yourself an admin --------------------------------------------------
-- Replace the address with the email you sign in with, then run this line.
insert into public.app_admins (email) values ('your.name@example.com')
on conflict do nothing;
