// UniFi Enterprise Sales Approval: email notifications (Supabase Edge Function)
//
// Called by the web page with the signed-in user's session:
//   { type: "submitted", id, xlsx }  -> emails the team (NOTIFY_TO) with the Excel file attached
//   { type: "status", id }           -> (admins only) emails the submitter the new status
//
// Mail is sent with Resend (RESEND_API_KEY) if set, otherwise over SMTP (SMTP_HOST ...).
// Secrets: see README, section "Email".

import { createClient } from "npm:@supabase/supabase-js@2.45.4";
import nodemailer from "npm:nodemailer@6.9.14";

const CORS = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const env = (k: string, fallback = "") => Deno.env.get(k) ?? fallback;
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
const esc = (v: unknown) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));

type Attachment = { filename: string; content: string }; // base64
type Mail = { to: string[]; subject: string; html: string; text: string; attachments?: Attachment[] };

async function sendMail(m: Mail): Promise<void> {
  const from = env("MAIL_FROM");
  if (!from) throw new Error("MAIL_FROM is not set");
  const resendKey = env("RESEND_API_KEY");
  if (resendKey) {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: m.to, subject: m.subject, html: m.html, text: m.text, attachments: m.attachments }),
    });
    if (!r.ok) throw new Error(`Resend ${r.status}: ${await r.text()}`);
    return;
  }
  const host = env("SMTP_HOST");
  if (!host) throw new Error("Set RESEND_API_KEY or SMTP_HOST");
  const port = Number(env("SMTP_PORT", "465"));
  const transport = nodemailer.createTransport({
    host, port, secure: port === 465,
    auth: { user: env("SMTP_USER"), pass: env("SMTP_PASS") },
  });
  await transport.sendMail({
    from, to: m.to.join(", "), subject: m.subject, html: m.html, text: m.text,
    attachments: (m.attachments ?? []).map((a) => ({ filename: a.filename, content: a.content, encoding: "base64" })),
  });
}

// deno-lint-ignore no-explicit-any
function rowsHtml(rows: [string, any][]) {
  return `<table cellpadding="6" style="border-collapse:collapse;font:14px -apple-system,Segoe UI,Arial,sans-serif">${
    rows.map(([k, v]) =>
      `<tr><td style="color:#6e6e73;vertical-align:top;white-space:nowrap">${esc(k)}</td><td style="white-space:pre-wrap">${esc(v)}</td></tr>`
    ).join("")
  }</table>`;
}
// deno-lint-ignore no-explicit-any
const rowsText = (rows: [string, any][]) => rows.map(([k, v]) => `${k}: ${v ?? ""}`).join("\n");
// deno-lint-ignore no-explicit-any
const products = (d: any) =>
  (d?.products ?? []).filter((p: { sku?: string }) => p?.sku).map((p: { sku: string; qty: number }) => `${p.sku} × ${p.qty}`).join("\n");
const fmtDate = (iso?: string) => (iso && /^\d{4}-\d{2}-\d{2}$/.test(iso) ? iso.split("-").reverse().join("/") : iso ?? "");

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  try {
    const url = env("SUPABASE_URL");
    const asUser = createClient(url, env("SUPABASE_ANON_KEY"), {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const admin = createClient(url, env("SUPABASE_SERVICE_ROLE_KEY"));

    const { data: { user } } = await asUser.auth.getUser();
    if (!user) return json({ error: "not_signed_in" }, 401);

    const body = await req.json().catch(() => ({}));
    const appUrl = env("APP_URL");

    // Row is read with the caller's rights, so access rules decide what they may touch.
    const { data: row, error } = await asUser.from("requests").select("*").eq("id", body.id).single();
    if (error || !row) return json({ error: "not_found" }, 404);
    const d = row.data ?? {};

    if (body.type === "submitted") {
      if (row.user_id !== user.id) return json({ error: "forbidden" }, 403);
      if (row.notified_at) return json({ ok: true, skipped: "already_sent" });
      const to = env("NOTIFY_TO").split(",").map((s) => s.trim()).filter(Boolean);
      if (!to.length) throw new Error("NOTIFY_TO is not set");
      const xlsx = typeof body.xlsx === "string" ? body.xlsx : "";
      if (xlsx.length > 4_000_000) return json({ error: "attachment_too_large" }, 413);

      const rows: [string, unknown][] = [
        ["Reference", row.ref],
        ["Submitted by", row.user_email],
        ["Intended use", d.use],
        ["Seller", `${d.seller?.company ?? ""} (${d.seller?.country ?? ""})`],
        ["End user", `${d.end?.company ?? ""} (${d.end?.country ?? ""})`],
        ["Products", products(d)],
        ["Estimated sales date", fmtDate(d.salesDate)],
        ["Order number", d.orderNo || "Not provided"],
        ["Project scope", d.scope],
      ];
      await sendMail({
        to,
        subject: `New UniFi Enterprise request ${row.ref} – ${d.seller?.company ?? ""}`,
        html: `<p>A new UniFi Enterprise sales approval request was submitted. The completed form is attached.</p>${rowsHtml(rows)}${
          appUrl ? `<p><a href="${esc(appUrl)}#requests">Open the request list</a></p>` : ""
        }`,
        text: `A new UniFi Enterprise sales approval request was submitted.\n\n${rowsText(rows)}${appUrl ? `\n\n${appUrl}#requests` : ""}`,
        attachments: xlsx ? [{ filename: `${row.ref} UniFi Enterprise Sales Approval.xlsx`, content: xlsx }] : [],
      });
      await admin.from("requests").update({ notified_at: new Date().toISOString() }).eq("id", row.id);
      return json({ ok: true });
    }

    if (body.type === "status") {
      const { data: isAdmin } = await asUser.rpc("is_admin");
      if (!isAdmin) return json({ error: "forbidden" }, 403);
      if (row.status === "Pending") return json({ ok: true, skipped: "pending" });
      const approved = row.status === "Approved";
      const rows: [string, unknown][] = [
        ["Reference", row.ref],
        ["Status", row.status],
        ["Seller", d.seller?.company],
        ["End user", d.end?.company],
        ["Products", products(d)],
      ];
      await sendMail({
        to: [row.user_email],
        subject: `${row.status}: UniFi Enterprise request ${row.ref}`,
        html: `<p>Your UniFi Enterprise sales approval request <b>${esc(row.ref)}</b> was <b>${esc(row.status.toLowerCase())}</b>.</p>${rowsHtml(rows)}${
          appUrl ? `<p><a href="${esc(appUrl)}#my-requests">See your requests</a></p>` : ""
        }${approved ? "" : "<p>If you have questions, reply to this email or contact your EET account manager.</p>"}`,
        text: `Your UniFi Enterprise sales approval request ${row.ref} was ${row.status.toLowerCase()}.\n\n${rowsText(rows)}${
          appUrl ? `\n\n${appUrl}#my-requests` : ""
        }`,
      });
      return json({ ok: true });
    }

    return json({ error: "unknown_type" }, 400);
  } catch (e) {
    console.error(e);
    return json({ error: "send_failed", detail: String((e as Error)?.message ?? e) }, 500);
  }
});
