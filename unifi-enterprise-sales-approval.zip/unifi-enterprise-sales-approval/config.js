// Settings for the web page. These values are safe to publish:
// the anon key only allows what the database rules in supabase/schema.sql allow.
window.ESA_CONFIG = {
  // Supabase -> Project Settings -> API
  supabaseUrl: "https://YOUR-PROJECT-ID.supabase.co",
  supabaseAnonKey: "YOUR-ANON-KEY",

  // Only these email domains can sign in from the page. Leave [] to allow any email.
  allowedDomains: [],

  // Show a "Continue with Microsoft" button (needs the Azure provider set up in Supabase, see README).
  microsoftLogin: false
};
