# UniFi Enterprise Sales Approval

Formularz do zgłaszania sprzedaży produktów UniFi Enterprise, krok po kroku, w stylu Apple Liquid Glass.

- Logowanie linkiem wysłanym na e-mail (bez haseł), opcjonalnie kontem Microsoft.
- Każdy widzi tylko swoje zgłoszenia i ich status (**My requests**).
- Admin widzi wszystkie zgłoszenia, zmienia status i eksportuje je do Excela (**All requests**).
- Po wysłaniu zgłoszenia zespół dostaje e-mail z wypełnionym plikiem Excel w załączniku.
- Po zmianie statusu (Approved / Rejected) zgłaszający dostaje e-mail z decyzją.

## Jak to jest zbudowane

| Część | Gdzie działa | Plik |
| --- | --- | --- |
| Strona (formularz, listy, Excel) | GitHub Pages | `index.html`, `config.js`, `assets/` |
| Logowanie i baza zgłoszeń z regułami dostępu | Supabase | `supabase/schema.sql` |
| Wysyłka maili | Supabase Edge Function | `supabase/functions/notify/index.ts` |
| Serwer pocztowy | Resend albo Twoja skrzynka (SMTP) | ustawienia w Supabase |

Wszystko ma darmowe plany, które wystarczą na pokaz.

---

## 1. Supabase: projekt i baza (ok. 10 min)

1. Załóż konto na [supabase.com](https://supabase.com) i utwórz projekt (**New project**). Region: **Central EU (Frankfurt)**, żeby dane były w UE.
2. Otwórz **SQL Editor → New query**.
3. Wklej całą zawartość `supabase/schema.sql`. W ostatniej linii zamień `your.name@example.com` na adres, którym będziesz się logować. To konto zostanie adminem.
4. Kliknij **Run**. Powinno pojawić się `Success`.

Dodanie kolejnego admina (w SQL Editor):

```sql
insert into public.app_admins (email) values ('kolega@firma.com');
```

## 2. Supabase: logowanie

1. **Authentication → Sign In / Providers → Email**: upewnij się, że jest włączony.
2. **Authentication → URL Configuration**:
   - **Site URL**: adres strony z kroku 5, np. `https://twoj-login.github.io/unifi-enterprise-sales-approval/`
   - **Redirect URLs**: dodaj ten sam adres oraz `http://localhost:8080/` (do testów na komputerze).
3. Wbudowana poczta Supabase wysyła tylko kilka maili z linkiem logowania na godzinę. Na pokaz to wystarczy. Przy większej liczbie osób ustaw własny serwer pocztowy w **SMTP Settings** (w panelu Authentication albo Project Settings → Authentication, zależnie od wersji panelu; te same dane co w kroku 4), a potem podnieś limit w **Rate Limits**.

## 3. Strona: `config.js`

W Supabase otwórz **Project Settings → API** (albo **API Keys**) i skopiuj:

- **Project URL** → `supabaseUrl`
- **anon public** albo **Publishable key** → `supabaseAnonKey`

```js
window.ESA_CONFIG = {
  supabaseUrl: "https://abcdefgh.supabase.co",
  supabaseAnonKey: "eyJhbGciOi...",
  allowedDomains: ["eetgroup.com"],   // [] = dowolny e-mail
  microsoftLogin: false
};
```

Ten klucz może być publiczny: pozwala tylko na to, na co pozwalają reguły z `schema.sql`. **Nigdy** nie wpisuj tu klucza `service_role` ani haseł do poczty.

## 4. Wysyłka maili

### 4a. Wybierz serwer pocztowy

**Opcja A: Resend (najprościej)**

1. Załóż konto na [resend.com](https://resend.com) i utwórz **API Key**.
2. Bez własnej domeny Resend wysyła tylko na adres, którym założyłeś konto, z nadawcy `onboarding@resend.dev`. Na pokaz ustaw `NOTIFY_TO` na swój adres. Żeby wysyłać do innych, dodaj i zweryfikuj domenę w Resend (**Domains**).

**Opcja B: Twoja skrzynka przez SMTP (np. Gmail)**

1. Włącz weryfikację dwuetapową na koncie Google.
2. Utwórz **hasło aplikacji**: [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords).
3. Użyj serwera `smtp.gmail.com`, port `465`. Porty 25 i 587 mogą być zablokowane w Supabase, więc zostań przy 465.

### 4b. Wdróż funkcję `notify`

**Przez przeglądarkę:** **Edge Functions → Deploy a new function → Via Editor**, nazwa `notify`, wklej zawartość `supabase/functions/notify/index.ts`, **Deploy**.

**Albo przez terminal** (Node.js zainstalowany na komputerze):

```bash
npx supabase login
npx supabase link --project-ref TWOJ_PROJECT_ID
npx supabase functions deploy notify
```

### 4c. Ustaw sekrety funkcji

**Edge Functions → Secrets** (albo `npx supabase secrets set NAZWA=wartość`):

| Sekret | Przykład | Opis |
| --- | --- | --- |
| `MAIL_FROM` | `UniFi Approval <onboarding@resend.dev>` | nadawca; przy Gmailu Twój adres Gmail |
| `NOTIFY_TO` | `zespol@firma.com` | kto dostaje Excela po zgłoszeniu (kilka adresów po przecinku) |
| `APP_URL` | `https://twoj-login.github.io/unifi-enterprise-sales-approval/` | link w mailach |
| `RESEND_API_KEY` | `re_...` | tylko opcja A |
| `SMTP_HOST` | `smtp.gmail.com` | tylko opcja B |
| `SMTP_PORT` | `465` | tylko opcja B |
| `SMTP_USER` | `twoj.adres@gmail.com` | tylko opcja B |
| `SMTP_PASS` | hasło aplikacji | tylko opcja B |
| `ALLOWED_ORIGIN` | `https://twoj-login.github.io` | opcjonalnie: tylko Twoja strona może wywołać funkcję |

`SUPABASE_URL`, `SUPABASE_ANON_KEY` i `SUPABASE_SERVICE_ROLE_KEY` Supabase podaje funkcji sam.

## 5. GitHub i publikacja strony

1. Na [github.com](https://github.com) kliknij **New repository**, nazwa np. `unifi-enterprise-sales-approval`.
2. Wrzuć pliki z tego folderu: **Add file → Upload files** i przeciągnij całą zawartość (z folderami `assets` i `supabase`). Albo w terminalu:

   ```bash
   git init
   git add .
   git commit -m "UniFi Enterprise Sales Approval"
   git branch -M main
   git remote add origin https://github.com/TWOJ_LOGIN/unifi-enterprise-sales-approval.git
   git push -u origin main
   ```

3. **Settings → Pages → Build and deployment → Source: Deploy from a branch**, branch `main`, folder `/ (root)`, **Save**.
4. Po minucie strona jest pod `https://TWOJ_LOGIN.github.io/unifi-enterprise-sales-approval/`.
5. Wpisz ten adres w Supabase (krok 2, Site URL i Redirect URLs) oraz w sekrecie `APP_URL`.

Na darmowym koncie GitHub Pages działa tylko dla repozytoriów **publicznych**. W repozytorium jest kod i grafika, a nie dane ze zgłoszeń (te są w Supabase). Jeśli kod lub grafika „Come together” nie mogą być publiczne, użyj płatnego GitHub albo opublikuj stronę przez [Vercel](https://vercel.com) lub [Netlify](https://netlify.com) z prywatnego repozytorium.

## 6. Test przed pokazem

- [ ] Otwórz stronę, wpisz swój e-mail (admin), kliknij link z maila. W nagłówku widać **All requests**.
- [ ] W drugiej przeglądarce (albo oknie incognito) zaloguj się innym adresem i wyślij zgłoszenie z 2 produktami.
- [ ] Na adres z `NOTIFY_TO` przyszedł mail z plikiem `ESA-....xlsx`.
- [ ] Jako admin otwórz zgłoszenie, ustaw **Approved**. Zgłaszający dostaje mail z decyzją.
- [ ] Zgłaszający widzi w **My requests** status Approved z oznaczeniem **Updated**.
- [ ] Zgłaszający nie widzi **All requests** ani cudzych zgłoszeń.

Gdy mail nie dochodzi: **Edge Functions → notify → Logs** pokazuje dokładny błąd (np. zły klucz, brak sekretu `MAIL_FROM`).

## Test na własnym komputerze (bez GitHub)

```bash
python3 -m http.server 8080
```

Otwórz `http://localhost:8080/`. Adres musi być dodany w Redirect URLs (krok 2).

## Opcjonalnie: logowanie kontem Microsoft

1. [portal.azure.com](https://portal.azure.com) → **Microsoft Entra ID → App registrations → New registration**.
   - Supported account types: konta w dowolnym katalogu (lub tylko Twoja organizacja).
   - Redirect URI (Web): `https://TWOJ_PROJECT_ID.supabase.co/auth/v1/callback`
2. **Certificates & secrets → New client secret**: skopiuj wartość.
3. W Supabase: **Authentication → Sign In / Providers → Azure**: wpisz Application (client) ID, secret i (dla jednej organizacji) Azure Tenant URL `https://login.microsoftonline.com/TENANT_ID`.
4. W `config.js` ustaw `microsoftLogin: true`.

Do kont firmowych EET może być potrzebna zgoda administratora IT na aplikację. Na pokaz wystarczy rejestracja w prywatnym katalogu Azure.

## Zmiany na później

- **Lista produktów (SKU):** w `index.html` szukaj `const SKUS = [` i dopisz `["NOWY-SKU","W123456789"]`.
- **Teksty i kolory:** zmienne kolorów są na początku sekcji `<style>` w `index.html`.

## Bezpieczeństwo i dane

- Reguły dostępu są w bazie (Row Level Security), nie tylko na stronie. Zwykły użytkownik nie odczyta cudzych zgłoszeń ani nie zmieni statusu, nawet obchodząc stronę.
- Klucz `service_role` i hasła do poczty są tylko w sekretach funkcji.
- Do pokazu używaj danych testowych. Zanim trafią tu prawdziwe dane klientów, uzgodnij to z IT i osobą odpowiedzialną za RODO (Supabase, Resend i GitHub to usługi zewnętrzne).
